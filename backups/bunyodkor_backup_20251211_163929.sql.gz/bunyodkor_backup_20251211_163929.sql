--
-- PostgreSQL database dump
--

\restrict XuBnvTfUjDWCnnswiWoUUThkqEZYF4RPU4nwyAyLMc5Kw4iufbfdL2Rh7MLUP2R

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: attendances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendances (
    id integer NOT NULL,
    status character varying(20) NOT NULL,
    comment text,
    session_id integer NOT NULL,
    student_id integer NOT NULL,
    marked_by_user_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: attendances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendances_id_seq OWNED BY public.attendances.id;


--
-- Name: contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contracts (
    id integer NOT NULL,
    contract_number character varying(50) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    monthly_fee numeric(15,2) NOT NULL,
    status character varying(20) NOT NULL,
    terminated_by_user_id integer,
    termination_reason text,
    student_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    terminated_at timestamp with time zone,
    birth_year integer NOT NULL,
    sequence_number integer NOT NULL,
    passport_copy_url text,
    form_086_url text,
    heart_checkup_url text,
    birth_certificate_url text,
    contract_images_urls text,
    signature_url text,
    signature_token character varying(255),
    signed_at timestamp with time zone,
    final_pdf_url text,
    custom_fields text,
    group_id integer,
    archive_year integer DEFAULT 2025 NOT NULL
);


--
-- Name: contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contracts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contracts_id_seq OWNED BY public.contracts.id;


--
-- Name: gate_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gate_logs (
    id integer NOT NULL,
    allowed boolean NOT NULL,
    reason character varying(255),
    gate_timestamp timestamp with time zone NOT NULL,
    student_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: gate_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gate_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gate_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gate_logs_id_seq OWNED BY public.gate_logs.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    schedule_days character varying(255),
    schedule_time character varying(50),
    coach_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    capacity integer DEFAULT 100 NOT NULL,
    archive_year integer DEFAULT 2025 NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    birth_year integer NOT NULL
);


--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: parents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parents (
    id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    phone character varying(20) NOT NULL,
    email character varying(255),
    relationship_type character varying(50),
    student_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: parents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parents_id_seq OWNED BY public.parents.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    code character varying(100) NOT NULL,
    description character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: role_permission_association; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permission_association (
    role_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    session_date date NOT NULL,
    topic character varying(500),
    start_time character varying(10),
    end_time character varying(10),
    group_id integer NOT NULL,
    created_by_user_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.students (
    id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    date_of_birth date NOT NULL,
    phone character varying(20),
    address text,
    photo_url character varying(500),
    face_id character varying(255),
    status character varying(20) NOT NULL,
    group_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    archive_year integer DEFAULT 2025 NOT NULL
);


--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    value text,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    external_id character varying(255),
    amount numeric(15,2) NOT NULL,
    source character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    paid_at timestamp with time zone,
    comment text,
    payment_year integer,
    payment_months json,
    student_id integer,
    contract_id integer,
    created_by_user_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: user_role_association; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_role_association (
    user_id integer NOT NULL,
    role_id integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    phone character varying(20) NOT NULL,
    email character varying(255),
    full_name character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    is_super_admin boolean NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: waiting_list; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.waiting_list (
    id integer NOT NULL,
    student_id integer NOT NULL,
    group_id integer NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    notes text,
    added_by_user_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: waiting_list_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.waiting_list_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: waiting_list_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.waiting_list_id_seq OWNED BY public.waiting_list.id;


--
-- Name: attendances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances ALTER COLUMN id SET DEFAULT nextval('public.attendances_id_seq'::regclass);


--
-- Name: contracts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts ALTER COLUMN id SET DEFAULT nextval('public.contracts_id_seq'::regclass);


--
-- Name: gate_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gate_logs ALTER COLUMN id SET DEFAULT nextval('public.gate_logs_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: parents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parents ALTER COLUMN id SET DEFAULT nextval('public.parents_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: waiting_list id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waiting_list ALTER COLUMN id SET DEFAULT nextval('public.waiting_list_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
79e5dddd2085
\.


--
-- Data for Name: attendances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendances (id, status, comment, session_id, student_id, marked_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contracts (id, contract_number, start_date, end_date, monthly_fee, status, terminated_by_user_id, termination_reason, student_id, created_at, updated_at, terminated_at, birth_year, sequence_number, passport_copy_url, form_086_url, heart_checkup_url, birth_certificate_url, contract_images_urls, signature_url, signature_token, signed_at, final_pdf_url, custom_fields, group_id, archive_year) FROM stdin;
32	N192010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	39	2025-12-07 02:23:36.143022+05	2025-12-10 23:41:20.173308+05	\N	2010	17	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/879d0ebe-1e57-4b37-923c-16c0a7ffd142.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/5048f032-18d2-4f23-b8bb-e13af53e09f5.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/f515fc32-e9d2-45c6-8015-af58e79ce1f1.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/1f8ecc9b-4fbb-4e2a-a9a8-be650c0d8d61.png	\N	\N	\N	\N	\N	{"contract_number": "N192010", "buyurtmachi": {"fio": " Каримович Ахмедов  Каримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"contract_number": "N162010", "fio": "Ахмедов Шоҳруҳ Дилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "tugilganlik_yil": 2010, "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
16	N32010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	15	2025-12-07 00:27:58.38731+05	2025-12-10 23:41:20.173308+05	\N	2010	3	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/c16c6e6f-bfae-43a5-8e8c-4f380a522d2f.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/cf62afbe-6248-449f-a40e-3b3690480ba1.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/f8882d2d-6586-46fe-91ca-ec34bd3071ff.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/6ad4357c-1413-4d8a-8603-c73554594865.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/589f5a7a-9a3a-4904-90b3-629662edb85c.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/e01de639-847f-4adb-a282-3bf5ea6d7946.png"]	\N	\N	\N	\N	{"contract_number": "N32010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
18	N42010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	17	2025-12-07 00:29:51.574794+05	2025-12-10 23:41:20.173308+05	\N	2010	4	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/06ff7b90-7629-4e07-9ae9-89f1cc55a03b.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/1ba7c393-716e-4be3-b363-2b9cb088c1f1.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/b25f192f-b02d-4be3-bbee-6484428f881c.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/fca71ad9-e6b1-4836-82e6-3c8245b778db.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/dcffc2e5-66ef-432f-b212-d9f6754b5e2c.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/5be6bbd3-c5b0-4e86-8735-f25f148c770f.png"]	\N	\N	\N	\N	{"contract_number": "N42010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
29	N222010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	33	2025-12-07 01:52:40.746948+05	2025-12-10 23:41:20.173308+05	\N	2010	14	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/131c7da5-0177-4325-b9d8-200ce5da341c.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/3817296c-fc09-4978-9e4e-34e237d532cb.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/951e7cea-9ded-4b94-b843-10c6dc8da384.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/e2b7fda7-6a5d-46d7-91fa-3cc55369db4a.png	\N	\N	\N	\N	\N	{"contract_number": "N222010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
14	N12010	2025-12-05	2026-12-05	600000.00	ACTIVE	\N	\N	6	2025-12-05 22:06:18.455785+05	2025-12-10 23:41:20.173308+05	\N	2010	1	https://upload.wikimedia.org/wikipedia/commons/3/36/Passport_placeholder.png	https://upload.wikimedia.org/wikipedia/commons/3/36/Passport_placeholder.png	https://upload.wikimedia.org/wikipedia/commons/3/36/Passport_placeholder.png	https://upload.wikimedia.org/wikipedia/commons/3/36/Passport_placeholder.png	["https://upload.wikimedia.org/wikipedia/commons/3/36/Passport_placeholder.png", "https://upload.wikimedia.org/wikipedia/commons/3/36/Passport_placeholder.png"]	\N	808f3233-3e16-4ee8-ba0c-185b42166738	\N	\N	{"student": {"birth_year": 2010, "first_name": "Sherzod", "last_name": "O‘rinboyev", "patronymic": "Alisher o‘g‘li", "address": "Toshkent sh., Chilonzor tumani, Oqtepa ko‘chasi 12-uy", "phone": "+998 90 123 45 67"}, "father": {"full_name": "O‘rinboyev Alisher Hasanovich", "occupation": "Dasturchi", "phone": "+998 90 111 22 33"}, "mother": {"full_name": "O‘rinboyeva Dilnoza Karimovna", "occupation": "O‘qituvchi", "phone": "+998 90 222 33 44"}, "contract_creation_date": "2025-12-05", "parent_passport": {"series_number": "AA 1234567", "issued_by": "Toshkent sh. IIBB Chilonzor bo‘limi", "issue_date": "2018-03-15"}, "student_birth_certificate": {"full_name": "O‘rinboyev Sherzod Alisher o‘g‘li", "series": "I-AA 6543210", "issued_by": "Toshkent sh. FHB", "issue_date": "2010-06-10"}, "contract_terms": {"contract_start_date": "2025-12-05", "contract_end_date": "2026-12-05", "monthly_fee": 600000.0}, "customer": {"full_name": "O‘rinboyev Alisher Hasanovich", "passport_number": "AA 1234567", "passport_issued_by": "Toshkent sh. IIBB Chilonzor bo‘limi", "passport_issue_date": "2018-03-15", "address": "Toshkent sh., Chilonzor tumani, Oqtepa ko‘chasi 12-uy", "phone": "+998 90 111 22 33"}}	1	2025
4	4455	2025-10-03	2026-12-03	600000.00	TERMINATED	1	string	4	2025-12-03 20:17:14.583748+05	2025-12-03 20:31:29.169338+05	\N	2000	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025
20	N52010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	19	2025-12-07 00:36:50.533411+05	2025-12-10 23:41:20.173308+05	\N	2010	5	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/bb3d23c8-6a16-4fa1-a53a-007ff1ac13e9.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/3850ffd0-b871-46b1-9364-0528a6c49dba.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/c9d86ed7-07d6-4616-b21b-a41803d279fe.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/3a80b6f5-21d8-4089-9c18-e92776150a95.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/e35f2aeb-6dbb-4718-83d9-22b30fb30a96.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/a6d3156a-6ab1-446d-9b3d-71dab93c4d20.png"]	\N	\N	\N	\N	{"contract_number": "N52010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
21	N62010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	21	2025-12-07 00:40:27.039282+05	2025-12-10 23:41:20.173308+05	\N	2010	6	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/c4e877ce-ef12-4dc5-804d-dbb783610321.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/1b7ffc52-c199-41c8-ae6f-45e67faa7050.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/663bd400-5335-4277-9a9d-141352625c2f.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/9e9ad061-6a1d-47ed-a49e-9156bf890bff.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/4854f13e-008c-4a9c-9cc4-b98643963db6.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/75a80448-9c19-4715-a4db-38768aceccd3.png"]	\N	\N	\N	\N	{"contract_number": "N62010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
22	N72010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	22	2025-12-07 00:44:42.640258+05	2025-12-10 23:41:20.173308+05	\N	2010	7	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/ef0ca51b-5333-47ec-bdea-6dfa00c41b4c.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/82250277-0fde-4cd3-ae82-d76ac7a2e009.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/cb20d625-7487-4eee-b2fd-104bb9802104.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/dd1ff816-d8ef-48bb-962e-8db62d3dbcf6.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/bfe0b440-97ba-4e91-a53e-5f7464fcc761.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/5206d52c-1390-428a-8f79-b2315a89a83f.png"]	\N	\N	\N	\N	{"contract_number": "N72010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
23	N82010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	24	2025-12-07 00:49:33.735089+05	2025-12-10 23:41:20.173308+05	\N	2010	8	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/c85cbc50-a7bf-4863-a581-c34018e01c83.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/038f4e18-7649-427e-a5a1-fb2c9692a69f.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/082eec63-8d53-4420-903c-51954d0f0ff9.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/1937696a-448b-4c02-9578-c9fbf0a7fda5.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/1a72d1a9-e66b-4e5c-8b67-d48ab1ce41fd.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/f53da496-b63d-4fbe-a74f-67933d02baf6.png"]	\N	\N	\N	\N	{"contract_number": "N82010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
24	N92010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	25	2025-12-07 01:25:32.518+05	2025-12-10 23:41:20.173308+05	\N	2010	9	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/5cc352e1-3f93-49a8-97b2-fb0880f06a61.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/f6c5de86-1765-49fe-bab4-9a5c92f477ab.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/5586d0ee-7ad6-419e-83a5-9f469f8a0af3.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/48b7c450-562a-4730-8307-2db866937dbc.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/7eb118b9-b182-4e15-ae65-6816ea7a7857.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/1bc5625d-936b-40f1-9a67-634fd8e9d995.png"]	\N	\N	\N	\N	{"contract_number": "N92010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
25	N102010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	27	2025-12-07 01:28:29.951726+05	2025-12-10 23:41:20.173308+05	\N	2010	10	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/2148bda8-097a-4c03-8fba-1ef7703c4ad4.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/eee39d11-e613-4bb2-989d-67536b2a3e38.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/34a99ed7-52fb-408f-bbba-301690eb79f2.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/25e3ce4a-8409-4b76-8b2c-8d82fb551fb1.png	\N	\N	\N	\N	\N	{"contract_number": "N102010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
26	N122010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	29	2025-12-07 01:35:16.234244+05	2025-12-10 23:41:20.173308+05	\N	2010	11	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/45028313-30af-440d-a473-90269346b15f.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/a7838275-d090-40d2-afcc-bbf4fe09946b.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/1a9eb54d-c4ac-44be-ac89-098ce129f5ce.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/0502e369-b8e8-4129-a1b5-42720e398077.png	\N	\N	\N	\N	\N	{"contract_number": "N122010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
27	N1222010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	31	2025-12-07 01:40:45.967062+05	2025-12-10 23:41:20.173308+05	\N	2010	12	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/9683a11b-85f6-429c-85c5-d8c25af07e62.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/1c780166-c271-4dd3-8e70-2ccfb0bbd81b.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/8e5da0d1-e314-4819-9c16-cbdae5cc8bc1.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/2b549768-e1e4-4d85-b83b-920dd7334a60.png	\N	\N	\N	\N	\N	{"contract_number": "N1222010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
28	N1322010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	32	2025-12-07 01:48:49.801802+05	2025-12-10 23:41:20.173308+05	\N	2010	13	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/9b27617d-3009-474d-82ef-d0346643f678.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/ed523aca-7940-48b0-bb28-41733582413e.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/f487e59b-32b5-4ce4-9976-56eba8c7a24c.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/23f5c99a-e9e6-4529-9504-1a11a0773715.png	\N	\N	\N	\N	\N	{"contract_number": "N1322010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
33	N292010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	41	2025-12-07 02:26:16.132977+05	2025-12-10 23:41:20.173308+05	\N	2010	18	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/34dccc78-3041-4ac2-9ca1-0d70485fa042.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/b2991900-718c-4af4-8ff1-0e897484e33a.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/b3461d3a-632d-4f05-985e-dab51c533089.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/8e86d568-9809-45fa-9bf1-be5008ec954f.png	\N	\N	\N	\N	\N	{"contract_number": "N292010", "buyurtmachi": {"fio": " Каримович Ахмедов  Каримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"contract_number": "N162010", "fio": "Ахмедов Шоҳруҳ Дилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "tugilganlik_yil": 2010, "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
34	N392010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	42	2025-12-07 02:27:34.299445+05	2025-12-10 23:41:20.173308+05	\N	2010	19	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/9d16b627-208f-4dd6-bfbf-1d3bd7e93386.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/d63f3b01-d6f3-40a1-8f2d-33381cfea904.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/f8fc44cf-50ba-4f09-8bc0-24b92bca0d27.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/5b8885d4-5bdd-44b9-8444-0f254d4d16b2.png	\N	\N	\N	\N	\N	{"contract_number": "N392010", "buyurtmachi": {"fio": " Каримович Ахмедов  Каримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"contract_number": "N162010", "fio": "Ахмедов Шоҳруҳ Дилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "tugilganlik_yil": 2010, "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
35	N492010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	44	2025-12-07 02:28:24.625915+05	2025-12-10 23:41:20.173308+05	\N	2010	20	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/590cc615-f5af-4a6d-9f95-35e5f548efe1.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/96787e65-f2fe-4e2e-b69b-fc008331f1b6.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/1172c008-2e01-4d5d-9674-8d1f6add6c4e.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/3466770b-8291-44eb-9619-c4227413b4e1.png	\N	\N	\N	\N	\N	{"contract_number": "N492010", "buyurtmachi": {"fio": " Каримович Ахмедов  Каримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"contract_number": "N162010", "fio": "Ахмедов Шоҳруҳ Дилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "tugilganlik_yil": 2010, "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
36	N592010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	45	2025-12-07 02:31:52.476381+05	2025-12-10 23:41:20.173308+05	\N	2010	21	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/9403c39b-28ca-4698-b90e-b6f778f27a0a.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/06978e53-df86-4271-9575-c816b289d374.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/4db6ab30-c7c9-4b71-a8a6-570ede88485a.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/dd4a2aef-0038-4b35-8543-cbaddb58c3f6.png	\N	\N	\N	\N	\N	{"contract_number": "N592010", "buyurtmachi": {"fio": " Каримович Ахмедов  Каримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"contract_number": "N162010", "fio": "Ахмедов Шоҳруҳ Дилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "tugilganlik_yil": 2010, "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
37	N692010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	47	2025-12-07 02:32:10.516426+05	2025-12-10 23:41:20.173308+05	\N	2010	22	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/327dba85-3fc6-4208-bdb7-512e5e06a748.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/45add844-a2b7-4d60-a771-5c31ce47d0c0.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/cf8b662a-c136-438f-b19d-c6c02c26e8fb.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/0943f2fe-4c1f-421c-9b48-449e9716986d.png	\N	\N	\N	\N	\N	{"contract_number": "N692010", "buyurtmachi": {"fio": " Каримович Ахмедов  Каримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"contract_number": "N162010", "fio": "Ахмедов Шоҳруҳ Дилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "tugilganlik_yil": 2010, "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
38	N342010	2025-01-01	2025-12-31	600000.00	ACTIVE	\N	\N	48	2025-12-07 02:40:28.546095+05	2025-12-10 23:41:20.173308+05	\N	2012	1	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/09e8c43b-9b62-4b09-a6f2-9037f486d997.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/45259877-9574-4dec-8146-0024bf370ea8.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/c90e883a-e4a9-43ea-bc2d-5c7aca2412e5.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/86c93877-b82c-4089-a377-108f6f8ce547.png	\N	\N	\N	\N	\N	{"contract_number": "N342010", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012", "tugilganlik_yil": 2012}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2025}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
39	N12011	2025-01-01	2026-12-31	600000.00	ACTIVE	\N	\N	50	2025-12-09 20:22:20.709448+05	2025-12-10 23:41:20.173308+05	\N	2011	1	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/6660524b-47b4-4f7f-985f-dfc16e410a7f.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/c901db18-b885-4556-9918-6672ee01fbf0.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/e8c0d800-57f9-49cf-a614-1b3afa6cbe8c.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/841095f0-a2b6-43eb-8f17-74e034c4467e.png	[]	\N	\N	\N	\N	{"contract_number": "N12011", "buyurtmachi": {"fio": " Test User Oraliqivich", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"fio": "Test User Oraliqivich", "tugilganlik_yil": 2011, "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2026}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	2	2025
40	N222011	2025-01-01	2026-12-31	600000.00	ACTIVE	\N	\N	52	2025-12-09 20:33:52.328657+05	2025-12-10 23:41:20.173308+05	\N	2011	2	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/f28e6237-74f5-433d-9272-2eae0cf9c679.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/9bb51f99-c456-40db-82c2-30c784715fee.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/c41294ec-a8bb-4142-9aea-01190c7df2a0.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/73e13373-d4d0-4829-ac69-034f009a38f2.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/4895b662-5d91-45a5-81d0-d88f3bb09f40.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/b38ac8cc-28ef-4686-951b-b20d2496b081.png"]	\N	\N	\N	\N	{"contract_number": "N222011", "buyurtmachi": {"fio": " Test User Oraliqivich", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"fio": "Test User Oraliqivich", "tugilganlik_yil": 2011, "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2026}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	2	2025
41	N22011	2025-01-01	2026-12-31	600000.00	ACTIVE	\N	\N	53	2025-12-09 20:36:18.769356+05	2025-12-10 23:41:20.173308+05	\N	2011	3	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/4a733008-84bf-452f-9132-8cb27997d18d.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/b07934dd-bc27-4e29-ad8d-e03d306ee49d.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/0ac88582-c049-41ab-afb7-a1e92958df3c.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/9eab3c35-8b24-4bdf-92a1-ac294df93320.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/8fdea56b-dcc4-4e1c-9362-2388ad5a6716.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/4e28e50a-a300-458d-92da-9c3b4bd55857.png"]	\N	\N	\N	\N	{"contract_number": "N22011", "buyurtmachi": {"fio": " Test User Oraliqivich", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"fio": "Test User Oraliqivich", "tugilganlik_yil": 2011, "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2026}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	2	2025
46	N42012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	62	2025-12-09 23:27:23.960738+05	2025-12-10 23:41:20.173308+05	\N	2012	4	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/5d35c15e-5d12-4acc-bf3d-e0f8c905e45f.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/9f0ff469-d6f5-4222-a626-0d856c907996.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/6fe418ce-1120-4fe6-a1e3-e45fc5414036.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/e1b165e3-7a93-403b-bcb8-ce7c3e2c69ee.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/8eb0cec0-8edd-4ac0-bc43-9409d41ac64d.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/f42547bc-c073-42bc-9052-18dcbda19418.png"]	\N	\N	\N	https://cognilabs.s3.eu-north-1.amazonaws.com/contract-pdfs/N42012_649b0af0-1f41-4d8f-9318-6f136e033d95.pdf	{"contract_number": "N42012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
42	N0012025	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	56	2025-12-09 21:39:47.543418+05	2025-12-10 23:41:20.173308+05	\N	2011	1	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/491863df-373e-48a9-8c11-9d7873e8dde1.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/d841f9d5-626b-497a-babb-8b73e26967b8.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/a2ade3ae-b79d-450a-8b29-e730c5f3b4ab.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/b66a355d-6eea-481c-ab8e-44642e094007.png	[]	\N	\N	\N	\N	{"contract_number": "N0012025", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2011, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
43	N32012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	57	2025-12-09 21:49:29.303967+05	2025-12-10 23:41:20.173308+05	\N	2011	2	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/c03fe0fb-24af-42f5-9959-e387fca05695.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/11a4bc5b-b414-409b-be99-d6d42a44dd7b.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/e6ab000d-bc2a-4198-8d70-dbac7b4cbc1f.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/29a6f17a-fa50-441f-833a-131d19765827.png	[]	\N	\N	\N	\N	{"contract_number": "N32012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2011, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
44	N52012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	58	2025-12-09 22:02:17.935428+05	2025-12-10 23:41:20.173308+05	\N	2011	3	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/63aec2fb-5d14-42e9-976f-2a7c1baf02f1.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/c4b8ff45-a036-40eb-a4d3-7066f7cfaf88.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/5075a86d-5c5a-4bfa-bc9a-9f7a251961b0.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/30f4350c-29df-458b-80a4-d970d11c9397.png	[]	\N	\N	\N	\N	{"contract_number": "N52012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2011, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
45	N22012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	59	2025-12-09 23:24:37.567856+05	2025-12-10 23:41:20.173308+05	\N	2012	2	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/bc1879f8-6953-4b1e-bbf8-b40948a78c4b.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/9a5cad82-7361-445f-8873-4f6acfb585ca.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/ac0c0103-da55-426a-be35-873f30396ad8.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/266f2bec-1274-4bb8-ac5d-892f9374eca0.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/7a279653-0535-4625-9c82-97cdf0ea8943.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/1dd22904-6c9a-441d-8300-adc41cd9d537.png"]	\N	\N	\N	https://cognilabs.s3.eu-north-1.amazonaws.com/contract-pdfs/N22012_1753fe33-0d95-4780-9818-9322a9478dab.pdf	{"contract_number": "N22012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
47	N62012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	65	2025-12-09 23:44:37.818969+05	2025-12-10 23:41:20.173308+05	\N	2012	6	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/f713ee66-a6ee-411d-b7dc-81295f0465ff.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/83248ed7-6c57-4a46-b098-583cec58ea4a.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/88f65e89-02a2-45a0-8b98-65c78572cd8e.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/2e8c347f-9d37-4d3b-b368-7c2b848c5bb7.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/122501bb-3485-4ca7-b325-1a8395c77dce.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/01d2fb83-79f6-4c52-9d32-69f047400f48.png"]	\N	\N	\N	https://cognilabs.s3.eu-north-1.amazonaws.com/contract-pdfs/N62012_5c31f94b-6e55-471d-9d3d-6b3b35793b2f.pdf	{"contract_number": "N62012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
48	N72012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	66	2025-12-10 00:12:19.18404+05	2025-12-10 23:41:20.173308+05	\N	2012	7	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/b87cb278-6396-47af-ab48-a7c43c8ae7db.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/dd932758-1428-4a6e-abf8-03f8a8beac1e.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/2e0d033b-4752-4dfc-bdba-f5f1ef05a729.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/108c4fda-0df5-49f6-9bcc-d48dcd9f6585.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/db20edcc-b2c9-4f42-ac00-cb584b02f074.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/b39a6e79-e9a9-4cf7-a489-25af9fb8897d.png"]	\N	\N	\N	https://cognilabs.s3.eu-north-1.amazonaws.com/contract-pdfs/N72012_7abaf1ff-8162-4076-bf61-227c00ad31b2.pdf	{"contract_number": "N72012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
49	N82012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	67	2025-12-10 00:18:08.99098+05	2025-12-10 23:41:20.173308+05	\N	2012	8	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/48f672cd-30a3-46cb-83cd-72f1d42ebda0.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/1641aff7-dec7-4aa1-92df-c3781e2d2d0a.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/a182772a-6794-4fe9-91f1-36109d34d49d.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/25662ac6-6f04-4506-9180-fa350485c3e4.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/96ef551d-1f52-4358-97cb-e9bdd001259b.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/f26d95b9-21ab-4309-9340-084f73cc44d1.png"]	\N	\N	\N	\N	{"contract_number": "N82012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
50	N92012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	68	2025-12-10 00:18:45.8826+05	2025-12-10 23:41:20.173308+05	\N	2012	9	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/17c94df8-feb8-4bca-a7a9-6ba8351ee2d6.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/8b0884cb-18f2-4963-8ee0-721f9e3d3a9e.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/2e0c950a-662e-4225-99f0-c7b90415926c.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/3cfb1012-665f-4a18-9f96-8ceb1f2003fd.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/32c7e73b-cd5a-4584-b66f-2f48f3d5593a.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/c826af8c-af70-4a37-b024-400679cc2952.png"]	\N	\N	\N	\N	{"contract_number": "N92012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
51	N102012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	70	2025-12-10 00:19:24.157588+05	2025-12-10 23:41:20.173308+05	\N	2012	10	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/6cf4e39d-2351-4bbe-ac5d-ccf889cb88e1.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/51cd2fa2-b2a6-4245-b7e2-68510845cb65.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/ad36ef70-7655-45b4-ac2e-d8f20b76de2a.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/d585d860-e5e2-45aa-83d4-f0fb8d81637a.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/ad560b92-bcf8-4d66-b376-065ae56ce9c0.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/ea5e0bd5-772d-4bc0-adf2-c583f0f462e2.png"]	\N	\N	\N	\N	{"contract_number": "N102012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
52	N112012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	72	2025-12-10 00:20:07.314662+05	2025-12-10 23:41:20.173308+05	\N	2012	11	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/30b7dab6-13ea-42fd-b2a4-582c0ebec9cc.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/d462fbff-f3bc-410e-bede-e804b2a8ce3f.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/6be7ebe8-717f-4c3d-b8de-f41b344ee7d2.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/435576bd-df3f-42a5-957c-b28c2193def2.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/a18af3d4-e352-48ee-be06-f7dfc9dba38b.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/b212faa9-2b5f-4876-9982-8a968fbac8aa.png"]	\N	\N	\N	\N	{"contract_number": "N112012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
53	N122012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	73	2025-12-10 00:20:27.510626+05	2025-12-10 23:41:20.173308+05	\N	2012	12	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/024002c8-930c-489e-abbc-6f49594ffffa.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/150a72d2-b8b2-4d67-b175-591926e53161.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/7bb0a57e-0e39-47e6-8f9a-3e4e13acd221.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/03f55b71-690c-47c7-bd07-b5d48ed284ed.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/9f128288-0ecc-42ee-b95c-eff0fd2245ea.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/a3667ffc-bd38-4e83-8394-efc061c61f54.png"]	\N	\N	\N	\N	{"contract_number": "N122012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
54	N132012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	74	2025-12-10 00:22:08.733382+05	2025-12-10 23:41:20.173308+05	\N	2012	13	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/a7aa8092-ae0f-47a9-be45-06b74f5a4b9f.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/16c8ec7c-19b8-417f-91f3-52c98508b21d.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/823fe9f4-dfc4-4e14-b95a-70c1b4094b74.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/9bb7264c-b5af-4d1e-b171-5f0c045bb7f9.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/fefe1f75-75a4-4fc0-a18a-d397590d0560.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/a5d447f4-6a40-4ef9-864a-ebc38e7fcf80.png"]	\N	\N	\N	\N	{"contract_number": "N132012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
55	N142012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	75	2025-12-10 00:23:56.540321+05	2025-12-10 23:41:20.173308+05	\N	2012	14	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/467c1a97-ebae-4f24-a1f8-24acd05ceb5a.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/3ee721c2-0a32-42ba-81f9-2da34b96f154.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/03ff3928-3220-4f80-bd6d-e1ee5754794a.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/d8c08635-6ca1-4b66-9f59-08171de1e91b.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/01247a73-58ec-4365-af97-04393bc39c55.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/5e6b58a1-34c4-43c8-85e4-73252b85c6a9.png"]	\N	\N	\N	\N	{"contract_number": "N142012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
57	N162012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	77	2025-12-10 00:26:53.053455+05	2025-12-10 23:41:20.173308+05	\N	2012	16	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/fa2abf57-e9db-4514-83c8-a6a68a579e1a.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/d0933e3f-e8bf-42d2-86bf-1c1ba4191106.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/c2f8af90-4eee-4d9f-839b-36fbfe614280.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/6f456cf9-f4cb-47b6-8a20-282582ab763d.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/a8158940-8ae3-4632-978a-5b3189f0f86e.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/a7be9fef-86cf-44b1-ac73-72ceebeeb0ca.png"]	\N	\N	\N	\N	{"contract_number": "N162012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
60	N232010	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	81	2025-12-10 17:57:10.452835+05	2025-12-10 23:41:20.173308+05	\N	2010	23	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/c2c1f420-37e8-4689-950a-823819a70194.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/fb89a1c0-665d-4dea-9ab9-948b92a8919e.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/5c7e8144-1e6c-44f6-8abf-562f25b4000a.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/f7a90ec2-6101-4751-a50e-22f355b2010b.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/1931a2ed-5298-4dae-a8d9-7b112f32dd75.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/ef55cdda-928a-4c86-8091-29afda8dc9e0.png"]	\N	\N	\N	https://cognilabs.s3.eu-north-1.amazonaws.com/contract-pdfs/N232010_1151334f-725f-4ef6-a0bf-50bd2339d794.pdf	{"contract_number": "N232010", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2010, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
30	N322010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	35	2025-12-07 01:57:31.062371+05	2025-12-10 23:41:20.173308+05	\N	2010	15	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/f80b3753-0de8-43ac-ade8-78eddfd558cf.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/2a2b78f1-6dfa-4394-9064-8a39914cf2ef.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/cec97cc3-28b9-47e9-8464-5660376f1fd7.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/11d255dc-44b1-4172-9f39-77926d9a9f68.png	\N	\N	\N	\N	\N	{"contract_number": "N322010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
31	N422010	2025-01-01	2030-12-31	600000.00	ACTIVE	\N	\N	36	2025-12-07 02:05:28.592747+05	2025-12-10 23:41:20.173308+05	\N	2010	16	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/ae3c3b5c-5c35-4c82-8d0f-c278e3df2897.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/5a22aa54-1dc0-4340-8df1-6611c97bd35f.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/9a5cf96f-248d-43bb-8f4b-31c9f2cc35e1.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/9e3e4b53-239c-4ce5-a265-5b2c94e9e7e7.png	\N	\N	\N	\N	\N	{"contract_number": "N422010", "buyurtmachi": {"fio": " Каримович Ахмедов  ooКаримович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Чилонзор тумани ИИБ", "pasport_qachon_bergan": "01.01.2024", "manzil": "Тошкент ш, Чилонзор тумани, 1-даха, 12-уй, 34-хонадон", "telefon": "+998 90 123 45 67"}, "tarbiyalanuvchi": {"tugilganlik_yil": 2010, "fio": "Ахмедов Шоҳруҳ sfdgДилшодович", "tugilganlik_guvohnoma": "I-AA 1234567", "guvohnoma_kim_bergan": "Чилонзор тумани ФХДЁ бўлими илонзор тумани", "guvohnoma_qachon_bergan": "01.01.2016"}, "shartnoma_muddati": {"boshlanish": "2025-01-01", "tugash": "31", "yil": 2030}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
56	N152012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	76	2025-12-10 00:26:22.542009+05	2025-12-10 23:41:20.173308+05	\N	2012	15	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/06793d5b-e4aa-48e3-8feb-9b996c2647bc.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/436a86f2-c942-4cb2-99a5-7af2f90c522f.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/d2e73900-4a1d-4123-aa96-a230b542ebba.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/1edfd822-4112-4079-9827-4bf18a475ed8.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/4b704a11-cbae-4ac9-9fb6-a7b0f6b03a32.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/7f3a9f54-25aa-47f3-81a4-893d8acce3c6.png"]	\N	\N	\N	\N	{"contract_number": "N152012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
15	N22010	2025-12-06	2026-12-06	600000.00	ACTIVE	\N	\N	8	2025-12-06 20:24:20.244055+05	2025-12-10 23:41:20.173308+05	\N	2010	2	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/ae871ff3-2f00-4493-b00a-8b62514d0fd4.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/06a66ba6-5f67-4a6a-9b06-69a4b7d3f135.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/b5a1078b-6111-4bb4-b153-2236a06978f0.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/3b817e50-1128-419f-bd40-98142193a98b.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/84b9f80e-d058-456d-8fe8-b19f0b4b4b89.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/09268b11-52c8-4fe7-beac-cdc947e10925.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/9ae63ab0-4dc0-49d6-acba-e110f8bbdcd0.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/80550efa-79d9-45ea-aeaa-4b5726af0c13.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/25a842d3-6bfb-4b57-ae9a-397f40b1eab2.png"]	\N	\N	\N	\N	{"buyurtmachi": {"fio": "Tojiboyev Shohidbek", "pasport_seriya": "AB1234567", "pasport_kim_bergan": "Olmazor ROVD", "pasport_qachon_bergan": "2020-01-15", "manzil": "Toshkent, Chilonzor", "telefon": "998901234567"}, "tarbiyalanuvchi": {"fio": "Alvaro Marata", "tugilganlik_yil": 2010, "tugilganlik_guvohnoma": "I-AA N1234567", "guvohnoma_kim_bergan": "Toshkent RAGS", "guvohnoma_qachon_bergan": "2010-12-06"}, "shartnoma_muddati": {"boshlanish": "2025-12-06", "tugash": "2026-12-06"}, "tolov": {"oylik_narx": 600000}}	1	2025
1	1122	2025-10-03	2026-12-03	600000.00	ACTIVE	\N	\N	1	2025-12-03 20:16:45.920125+05	2025-12-10 23:41:20.173308+05	\N	2000	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025
58	N172012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	78	2025-12-10 00:28:20.250946+05	2025-12-10 23:41:20.173308+05	\N	2012	17	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/1edb2e7c-0e6b-4620-875c-71d0f534c2a5.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/581cb424-b5ac-46db-b956-a91d1e880e74.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/6f8b1471-a37d-4e81-ab3f-0083a6b4a654.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/93be36ff-b400-4855-ade8-54efc968ee7c.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/3ea2756f-6a08-467e-96ac-24176a17aa99.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/0c4bb489-e9e4-4cfa-a192-b0f5b632adcd.png"]	\N	\N	\N	\N	{"contract_number": "N172012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
59	N182012	2026-01-06	2026-12-06	600000.00	ACTIVE	\N	\N	80	2025-12-10 00:30:07.93117+05	2025-12-10 23:41:20.173308+05	\N	2012	18	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/cc883c47-79fd-4599-a474-c300eaf0faaa.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/90b7160c-5d12-4769-b3f3-a97d7fed04d7.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/27b8a866-f0ce-41b7-85dd-75898eeede65.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/3e8c31ee-421c-4c81-8405-87eea5b294fd.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/151e90ac-a791-4bd0-8d52-a1481c122d4f.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/ff8e19d4-330b-4a31-bc82-7024e87fd998.png"]	\N	\N	\N	https://cognilabs.s3.eu-north-1.amazonaws.com/contract-pdfs/N182012_1a7b9965-9c2f-49c5-95df-388f20c8b995.pdf	{"contract_number": "N182012", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2012", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2012, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2026-01-06", "tugash": "2026-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	1	2025
\.


--
-- Data for Name: gate_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gate_logs (id, allowed, reason, gate_timestamp, student_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.groups (id, name, description, schedule_days, schedule_time, coach_id, created_at, updated_at, capacity, archive_year, status, birth_year) FROM stdin;
1	U 17 yoshlar jamoasi	17 yoshdan kichik bolalar uchun	Du|Se|Chor	13:00-17:00	2	2025-12-03 20:10:36.370323+05	2025-12-10 23:41:20.173308+05	100	2025	ACTIVE	2015
2	U 21 yoshlar jamoasi	21yoshdan kichik bolalar uchun	Du|Se|Chor	15:00-17:00	2	2025-12-03 20:12:21.465541+05	2025-12-10 23:41:20.173308+05	100	2025	ACTIVE	2015
3	U 19yoshlar jamoasi	19 yoshdan kichik bolalar uchun	Du|Se|Chor	15:00-17:00	3	2025-12-03 20:12:41.628962+05	2025-12-10 23:41:20.173308+05	100	2025	ACTIVE	2015
\.


--
-- Data for Name: parents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parents (id, first_name, last_name, phone, email, relationship_type, student_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, code, description, created_at, updated_at) FROM stdin;
1	finance:transactions:view	View financial transactions	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
2	finance:unassigned:view	View unassigned transactions	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
3	finance:unassigned:assign	Assign unassigned transactions	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
4	finance:transactions:manual	Create manual transactions	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
5	finance:transactions:cancel	Cancel transactions	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
6	students:view	View students	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
7	students:edit	Edit students	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
8	students:manage	Full student management including import	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
9	groups:view	View groups	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
10	groups:edit	Edit groups	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
11	contracts:view	View contracts	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
12	contracts:edit	Edit contracts	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
13	attendance:coach:mark	Mark attendance as coach	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
14	attendance:view	View attendance records	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
15	reports:finance:view	View financial reports	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
16	reports:attendance:view	View attendance reports	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
17	reports:dashboard:view	View dashboard	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
18	settings:system:edit	Edit system settings	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
19	settings:system:view	View system settings	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
20	roles:manage	Manage roles and permissions	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
21	users:manage	Manage users	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
22	gate:logs:view	View gate logs	2025-12-03 19:55:05.241988+05	2025-12-03 19:55:05.241988+05
\.


--
-- Data for Name: role_permission_association; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permission_association (role_id, permission_id) FROM stdin;
2	16
2	22
2	2
2	17
2	11
2	19
2	1
2	14
2	9
2	15
2	6
3	5
3	2
3	17
3	3
3	4
3	11
3	1
3	15
3	6
4	6
4	13
4	14
4	9
5	12
5	22
5	10
5	7
5	17
5	11
5	8
5	14
5	9
5	6
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description, created_at, updated_at) FROM stdin;
1	Super Admin	Full system access	2025-12-03 19:55:05.268714+05	2025-12-03 19:55:05.268714+05
2	Director	Director with access to all reports and management	2025-12-03 19:55:05.268714+05	2025-12-03 19:55:05.268714+05
3	Accountant	Financial management and transactions	2025-12-03 19:55:05.268714+05	2025-12-03 19:55:05.268714+05
4	Coach	Coach with attendance marking capabilities	2025-12-03 19:55:05.268714+05	2025-12-03 19:55:05.268714+05
5	Admin	Administrative staff with student and group management	2025-12-03 19:55:05.268714+05	2025-12-03 19:55:05.268714+05
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, session_date, topic, start_time, end_time, group_id, created_by_user_id, created_at, updated_at) FROM stdin;
1	2025-12-03	Futbol o'ynimiz	12:00	14:00	3	3	2025-12-03 20:51:39.234062+05	2025-12-03 20:51:39.234062+05
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.students (id, first_name, last_name, date_of_birth, phone, address, photo_url, face_id, status, group_id, created_at, updated_at, archive_year) FROM stdin;
14	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:25:38.371294+05	2025-12-10 23:41:20.173308+05	2025
15	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:27:55.980863+05	2025-12-10 23:41:20.173308+05	2025
16	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:29:33.385376+05	2025-12-10 23:41:20.173308+05	2025
17	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:29:49.24321+05	2025-12-10 23:41:20.173308+05	2025
18	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:33:13.920165+05	2025-12-10 23:41:20.173308+05	2025
19	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:36:48.118129+05	2025-12-10 23:41:20.173308+05	2025
20	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:40:03.781192+05	2025-12-10 23:41:20.173308+05	2025
21	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:40:24.693059+05	2025-12-10 23:41:20.173308+05	2025
22	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:44:40.347772+05	2025-12-10 23:41:20.173308+05	2025
23	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:49:21.806072+05	2025-12-10 23:41:20.173308+05	2025
24	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:49:31.434256+05	2025-12-10 23:41:20.173308+05	2025
25	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 01:25:30.253315+05	2025-12-10 23:41:20.173308+05	2025
26	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 01:28:07.650846+05	2025-12-10 23:41:20.173308+05	2025
27	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 01:28:28.109187+05	2025-12-10 23:41:20.173308+05	2025
35	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 01:57:29.162693+05	2025-12-10 23:41:20.173308+05	2025
36	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 02:05:26.671617+05	2025-12-10 23:41:20.173308+05	2025
37	Aasdflvaro	Maasdfrata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 02:20:40.21002+05	2025-12-10 23:41:20.173308+05	2025
38	Aasdflvaro	Maasdfrata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 02:22:39.901239+05	2025-12-10 23:41:20.173308+05	2025
39	Aasdflvaro	Maasdfrata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 02:23:34.373835+05	2025-12-10 23:41:20.173308+05	2025
40	Aasdflvaro	Maasdfrata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 02:25:58.74616+05	2025-12-10 23:41:20.173308+05	2025
41	Aasdflvaro	Maasdfrata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 02:26:14.324032+05	2025-12-10 23:41:20.173308+05	2025
42	Aasdflvaro	Maasdfrata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 02:27:32.127795+05	2025-12-10 23:41:20.173308+05	2025
43	Aasdflvaro	Maasdfrata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 02:28:11.707111+05	2025-12-10 23:41:20.173308+05	2025
44	Aasdflvaro	Maasdfrata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 02:28:22.71137+05	2025-12-10 23:41:20.173308+05	2025
45	Aasdflvaro	Maasdfrata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 02:31:50.68444+05	2025-12-10 23:41:20.173308+05	2025
46	Aasdflvaro	Maasdfrata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 02:31:59.779897+05	2025-12-10 23:41:20.173308+05	2025
47	Aasdflvaro	Maasdfrata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 02:32:08.579799+05	2025-12-10 23:41:20.173308+05	2025
48	Aasdflvaro	Maasdfrata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 02:40:26.768974+05	2025-12-10 23:41:20.173308+05	2025
49	Test	User	2011-12-06	2345234543	Toshkent shahar	\N	\N	ACTIVE	2	2025-12-09 20:21:14.567273+05	2025-12-10 23:41:20.173308+05	2025
50	Test	User	2011-12-06	2345234543	Toshkent shahar	\N	\N	ACTIVE	2	2025-12-09 20:22:18.594751+05	2025-12-10 23:41:20.173308+05	2025
51	Test	User	2011-12-06	2345234543	Toshkent shahar	\N	\N	ACTIVE	2	2025-12-09 20:33:35.198107+05	2025-12-10 23:41:20.173308+05	2025
52	Test	User	2011-12-06	2345234543	Toshkent shahar	\N	\N	ACTIVE	2	2025-12-09 20:33:49.680965+05	2025-12-10 23:41:20.173308+05	2025
53	Test	User	2011-12-06	2345234543	Toshkent shahar	\N	\N	ACTIVE	2	2025-12-09 20:36:16.502683+05	2025-12-10 23:41:20.173308+05	2025
54	Javohir	ADmidn	2011-12-03	989015634567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-09 21:37:27.400757+05	2025-12-10 23:41:20.173308+05	2025
55	Javohir	ADmidn	2011-12-03	989015634567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-09 21:37:53.332634+05	2025-12-10 23:41:20.173308+05	2025
56	Javohir	ADmidn	2011-12-03	989015634567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-09 21:39:45.505889+05	2025-12-10 23:41:20.173308+05	2025
57	Javohir	ADmidn	2011-12-03	989015634567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-09 21:49:27.199169+05	2025-12-10 23:41:20.173308+05	2025
58	Javohir	ADmidn	2011-12-03	989015634567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-09 22:02:14.020145+05	2025-12-10 23:41:20.173308+05	2025
59	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-09 23:24:35.329535+05	2025-12-10 23:41:20.173308+05	2025
60	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-09 23:26:22.655657+05	2025-12-10 23:41:20.173308+05	2025
61	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-09 23:26:32.456887+05	2025-12-10 23:41:20.173308+05	2025
62	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-09 23:27:21.811+05	2025-12-10 23:41:20.173308+05	2025
63	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-09 23:43:50.250701+05	2025-12-10 23:41:20.173308+05	2025
64	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-09 23:44:24.102205+05	2025-12-10 23:41:20.173308+05	2025
65	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-09 23:44:35.573369+05	2025-12-10 23:41:20.173308+05	2025
66	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:12:16.366338+05	2025-12-10 23:41:20.173308+05	2025
67	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:18:06.481567+05	2025-12-10 23:41:20.173308+05	2025
68	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:18:42.854614+05	2025-12-10 23:41:20.173308+05	2025
69	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:18:54.005596+05	2025-12-10 23:41:20.173308+05	2025
70	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:19:08.343069+05	2025-12-10 23:41:20.173308+05	2025
71	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:19:55.139068+05	2025-12-10 23:41:20.173308+05	2025
72	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:20:04.365824+05	2025-12-10 23:41:20.173308+05	2025
73	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:20:24.926112+05	2025-12-10 23:41:20.173308+05	2025
74	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:22:03.981136+05	2025-12-10 23:41:20.173308+05	2025
75	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:23:53.521104+05	2025-12-10 23:41:20.173308+05	2025
76	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:26:19.523115+05	2025-12-10 23:41:20.173308+05	2025
77	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:26:50.494841+05	2025-12-10 23:41:20.173308+05	2025
78	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:28:17.460737+05	2025-12-10 23:41:20.173308+05	2025
79	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:28:25.720054+05	2025-12-10 23:41:20.173308+05	2025
80	Alvaro	Marata	2012-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 00:30:04.954584+05	2025-12-10 23:41:20.173308+05	2025
81	Alvaro	Marata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-10 17:57:07.576655+05	2025-12-10 23:41:20.173308+05	2025
1	Cristiano	Ronaldo	2000-12-03	566667788	Toshkent shahar	https://www.google.com/url?sa=i&url=https%3A%2F%2Fpixabay.com%2Fimages%2Fsearch%2Fprofile%2520icon%2F&psig=AOvVaw0lo97JjavayDJnD-cBB9cv&ust=1764861088640000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCND_5oTaoZEDFQAAAAAdAAAAABAE	asdfasdf	ACTIVE	1	2025-12-03 20:11:51.491713+05	2025-12-10 23:41:20.173308+05	2025
2	Lional	Messi	2000-12-03	566667788	Toshkent shahar	https://www.google.com/url?sa=i&url=https%3A%2F%2Fpixabay.com%2Fimages%2Fsearch%2Fprofile%2520icon%2F&psig=AOvVaw0lo97JjavayDJnD-cBB9cv&ust=1764861088640000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCND_5oTaoZEDFQAAAAAdAAAAABAE	asdfaasdf	ACTIVE	2	2025-12-03 20:14:16.392431+05	2025-12-10 23:41:20.173308+05	2025
3	Killian	Mbappe	2000-12-03	566662788	Toshkent shahar	https://www.google.com/url?sa=i&url=https%3A%2F%2Fpixabay.com%2Fimages%2Fsearch%2Fprofile%2520icon%2F&psig=AOvVaw0lo97JjavayDJnD-cBB9cv&ust=1764861088640000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCND_5oTaoZEDFQAAAAAdAAAAABAE	asddfaasdf	ACTIVE	3	2025-12-03 20:14:41.285808+05	2025-12-10 23:41:20.173308+05	2025
4	Arda	Guler	2000-12-03	566602788	Toshkent shahar	https://www.google.com/url?sa=i&url=https%3A%2F%2Fpixabay.com%2Fimages%2Fsearch%2Fprofile%2520icon%2F&psig=AOvVaw0lo97JjavayDJnD-cBB9cv&ust=1764861088640000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCND_5oTaoZEDFQAAAAAdAAAAABAE	asdff	ACTIVE	2	2025-12-03 20:15:16.244473+05	2025-12-10 23:41:20.173308+05	2025
5	kerak	kerak	2010-12-04	999222020	string	https://img.freepik.com/premium-vector/vector-flat-illustration-grayscale-avatar-user-profile-person-icon-profile-picture-suitable-social-media-profiles-icons-screensavers-as-templatex9xa_719432-1256.jpg?semt=ais_hybrid&w=740&q=80	asdfasdfasdf	ACTIVE	1	2025-12-04 21:23:13.680702+05	2025-12-10 23:41:20.173308+05	2025
6	document	document	2010-12-05	5656565656	toshkent	https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.istockphoto.com%2Fphotos%2Fprofile&psig=AOvVaw1yBzxp7whBWjKcaF9UxddH&ust=1765037248197000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCPDf5qvqppEDFQAAAAAdAAAAABAE	asdffff	ACTIVE	1	2025-12-05 21:08:06.454507+05	2025-12-10 23:41:20.173308+05	2025
7	strinasdfg	striasdfng	2025-12-05	3456345645	gsdfg sdfg	https://console.aws.amazon.com/	strifgng	ACTIVE	1	2025-12-06 00:25:57.458733+05	2025-12-10 23:41:20.173308+05	2025
8	Alvaro	Marata	2010-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-06 20:24:17.108203+05	2025-12-10 23:41:20.173308+05	2025
9	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:11:48.36772+05	2025-12-10 23:41:20.173308+05	2025
10	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:13:21.239768+05	2025-12-10 23:41:20.173308+05	2025
11	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:17:53.590428+05	2025-12-10 23:41:20.173308+05	2025
12	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:18:26.668526+05	2025-12-10 23:41:20.173308+05	2025
13	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 00:20:26.310394+05	2025-12-10 23:41:20.173308+05	2025
28	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 01:35:08.216803+05	2025-12-10 23:41:20.173308+05	2025
29	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 01:35:15.415127+05	2025-12-10 23:41:20.173308+05	2025
30	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 01:40:11.762746+05	2025-12-10 23:41:20.173308+05	2025
31	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 01:40:43.892551+05	2025-12-10 23:41:20.173308+05	2025
32	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 01:48:48.006564+05	2025-12-10 23:41:20.173308+05	2025
33	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 01:52:34.287945+05	2025-12-10 23:41:20.173308+05	2025
34	Kevin	De Brune	2010-12-06	998901234565	Toshkent shahar	\N	\N	ACTIVE	1	2025-12-07 01:57:18.158632+05	2025-12-10 23:41:20.173308+05	2025
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (id, key, value, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, external_id, amount, source, status, paid_at, comment, payment_year, payment_months, student_id, contract_id, created_by_user_id, created_at, updated_at) FROM stdin;
1	\N	600000.00	PAYME	SUCCESS	2025-12-03 20:20:01.365+05	string	2025	[11]	1	1	1	2025-12-03 20:20:26.769103+05	2025-12-03 20:20:26.769103+05
3	\N	600000.00	PAYME	SUCCESS	2025-12-10 19:16:40.587+05	zo'r	2026	[1]	81	60	1	2025-12-10 19:19:39.915479+05	2025-12-10 19:19:39.915479+05
\.


--
-- Data for Name: user_role_association; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_role_association (user_id, role_id) FROM stdin;
2	4
3	4
5	2
5	3
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, phone, email, full_name, hashed_password, is_super_admin, status, created_at, updated_at) FROM stdin;
1	+998901234567	string	Super Admin	$2b$12$HeNB0m.QCKvXWtC7n7IRY.5zcDzZ/snQEbeXgslH/Pm/Xbj0T2zoy	t	ACTIVE	2025-12-03 19:55:05.287977+05	2025-12-03 19:55:05.287977+05
2	899996655	user@example.com	string	$2b$12$6WkVVIXOC48FCw3JOfjOCeKT0b/RefG6rZAjJs2IuhLOfVWExLk9K	f	ACTIVE	2025-12-03 20:01:41.433718+05	2025-12-03 20:01:41.433718+05
3	899996645	user@gmail.com	string	$2b$12$6a8MZCAPzEJJBEKJ822FyeQGDZFIgzf2WBbtSQrHt5lWGh9Ss3mIq	f	ACTIVE	2025-12-03 20:02:01.458392+05	2025-12-03 20:02:01.458392+05
4	556667788	salom@gmail.com	asdfasdfasdf	$2b$12$lRC4LBJFvHvpW22mZ9fx1emYfasRszT9pTIoAng5LmitzOs7PoVjO	f	ACTIVE	2025-12-03 20:05:59.596832+05	2025-12-03 20:05:59.596832+05
5	112223344	test@gmail.com	test	$2b$12$KF0MfmWDvzWy5VWa8nE6DeB6awNEe/GvnJOQjNdcFbZ5QFpBJNBQq	f	ACTIVE	2025-12-03 21:29:09.347458+05	2025-12-03 21:29:33.157321+05
\.


--
-- Data for Name: waiting_list; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.waiting_list (id, student_id, group_id, priority, notes, added_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Name: attendances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendances_id_seq', 1, false);


--
-- Name: contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contracts_id_seq', 60, true);


--
-- Name: gate_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gate_logs_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.groups_id_seq', 3, true);


--
-- Name: parents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parents_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 22, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 5, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sessions_id_seq', 1, true);


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.students_id_seq', 81, true);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, false);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transactions_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: waiting_list_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.waiting_list_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: attendances attendances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_pkey PRIMARY KEY (id);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- Name: gate_logs gate_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gate_logs
    ADD CONSTRAINT gate_logs_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: parents parents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parents
    ADD CONSTRAINT parents_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permission_association role_permission_association_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission_association
    ADD CONSTRAINT role_permission_association_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: user_role_association user_role_association_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role_association
    ADD CONSTRAINT user_role_association_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: waiting_list waiting_list_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waiting_list
    ADD CONSTRAINT waiting_list_pkey PRIMARY KEY (id);


--
-- Name: ix_attendances_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_attendances_id ON public.attendances USING btree (id);


--
-- Name: ix_contracts_archive_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contracts_archive_year ON public.contracts USING btree (archive_year);


--
-- Name: ix_contracts_birth_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contracts_birth_year ON public.contracts USING btree (birth_year);


--
-- Name: ix_contracts_contract_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_contracts_contract_number ON public.contracts USING btree (contract_number);


--
-- Name: ix_contracts_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contracts_id ON public.contracts USING btree (id);


--
-- Name: ix_contracts_signature_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_contracts_signature_token ON public.contracts USING btree (signature_token);


--
-- Name: ix_gate_logs_gate_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gate_logs_gate_timestamp ON public.gate_logs USING btree (gate_timestamp);


--
-- Name: ix_gate_logs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gate_logs_id ON public.gate_logs USING btree (id);


--
-- Name: ix_groups_archive_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_groups_archive_year ON public.groups USING btree (archive_year);


--
-- Name: ix_groups_birth_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_groups_birth_year ON public.groups USING btree (birth_year);


--
-- Name: ix_groups_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_groups_id ON public.groups USING btree (id);


--
-- Name: ix_groups_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_groups_status ON public.groups USING btree (status);


--
-- Name: ix_parents_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_parents_id ON public.parents USING btree (id);


--
-- Name: ix_parents_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_parents_phone ON public.parents USING btree (phone);


--
-- Name: ix_permissions_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_permissions_code ON public.permissions USING btree (code);


--
-- Name: ix_permissions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_permissions_id ON public.permissions USING btree (id);


--
-- Name: ix_roles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_roles_id ON public.roles USING btree (id);


--
-- Name: ix_sessions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sessions_id ON public.sessions USING btree (id);


--
-- Name: ix_sessions_session_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sessions_session_date ON public.sessions USING btree (session_date);


--
-- Name: ix_students_archive_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_students_archive_year ON public.students USING btree (archive_year);


--
-- Name: ix_students_face_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_students_face_id ON public.students USING btree (face_id);


--
-- Name: ix_students_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_students_id ON public.students USING btree (id);


--
-- Name: ix_system_settings_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_system_settings_id ON public.system_settings USING btree (id);


--
-- Name: ix_system_settings_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_system_settings_key ON public.system_settings USING btree (key);


--
-- Name: ix_transactions_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_transactions_external_id ON public.transactions USING btree (external_id);


--
-- Name: ix_transactions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_transactions_id ON public.transactions USING btree (id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_phone ON public.users USING btree (phone);


--
-- Name: ix_waiting_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_waiting_list_id ON public.waiting_list USING btree (id);


--
-- Name: attendances attendances_marked_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_marked_by_user_id_fkey FOREIGN KEY (marked_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: attendances attendances_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: attendances attendances_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: contracts contracts_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: contracts contracts_terminated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_terminated_by_user_id_fkey FOREIGN KEY (terminated_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: contracts fk_contracts_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_contracts_group_id FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE SET NULL;


--
-- Name: contracts fk_contracts_terminated_by_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_contracts_terminated_by_user_id FOREIGN KEY (terminated_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: gate_logs gate_logs_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gate_logs
    ADD CONSTRAINT gate_logs_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE SET NULL;


--
-- Name: groups groups_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: parents parents_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parents
    ADD CONSTRAINT parents_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: role_permission_association role_permission_association_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission_association
    ADD CONSTRAINT role_permission_association_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permission_association role_permission_association_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission_association
    ADD CONSTRAINT role_permission_association_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sessions sessions_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: students students_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE SET NULL;


--
-- Name: user_role_association user_role_association_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role_association
    ADD CONSTRAINT user_role_association_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_role_association user_role_association_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role_association
    ADD CONSTRAINT user_role_association_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: waiting_list waiting_list_added_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waiting_list
    ADD CONSTRAINT waiting_list_added_by_user_id_fkey FOREIGN KEY (added_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: waiting_list waiting_list_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waiting_list
    ADD CONSTRAINT waiting_list_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: waiting_list waiting_list_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waiting_list
    ADD CONSTRAINT waiting_list_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict XuBnvTfUjDWCnnswiWoUUThkqEZYF4RPU4nwyAyLMc5Kw4iufbfdL2Rh7MLUP2R

