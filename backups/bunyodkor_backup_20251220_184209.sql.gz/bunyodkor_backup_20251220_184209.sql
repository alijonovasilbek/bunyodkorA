--
-- PostgreSQL database dump
--

\restrict O1rg5OcdLYsd5e6dobuwB0vRfJOvvhzz0PhBXxdvpVDlHImVFgwp7fepuaizFC2

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: attendances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendances (
    id integer NOT NULL,
    status character varying(20) NOT NULL,
    comment text,
    session_id integer NOT NULL,
    student_id integer NOT NULL,
    marked_by_user_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: attendances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendances_id_seq OWNED BY public.attendances.id;


--
-- Name: contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contracts (
    id integer NOT NULL,
    contract_number character varying(50) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    monthly_fee numeric(15,2) NOT NULL,
    status character varying(20) NOT NULL,
    archive_year integer DEFAULT 2025 NOT NULL,
    birth_year integer NOT NULL,
    sequence_number integer NOT NULL,
    passport_copy_url text,
    form_086_url text,
    heart_checkup_url text,
    birth_certificate_url text,
    contract_images_urls text,
    final_pdf_url text,
    custom_fields text,
    terminated_at timestamp with time zone,
    terminated_by_user_id integer,
    termination_reason text,
    student_id integer NOT NULL,
    group_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contracts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contracts_id_seq OWNED BY public.contracts.id;


--
-- Name: gate_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gate_logs (
    id integer NOT NULL,
    allowed boolean NOT NULL,
    reason character varying(255),
    gate_timestamp timestamp with time zone NOT NULL,
    student_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: gate_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gate_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gate_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gate_logs_id_seq OWNED BY public.gate_logs.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    identifier character varying(10) NOT NULL,
    description text,
    schedule_days character varying(255),
    schedule_time character varying(50),
    capacity integer NOT NULL,
    status character varying(20) NOT NULL,
    birth_year integer NOT NULL,
    archive_year integer DEFAULT 2025 NOT NULL,
    coach_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: parents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parents (
    id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    phone character varying(20) NOT NULL,
    email character varying(255),
    relationship_type character varying(50),
    student_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: parents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parents_id_seq OWNED BY public.parents.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    code character varying(100) NOT NULL,
    description character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: role_permission_association; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permission_association (
    role_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    session_date date NOT NULL,
    topic character varying(500),
    start_time character varying(10),
    end_time character varying(10),
    group_id integer NOT NULL,
    created_by_user_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.students (
    id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    date_of_birth date NOT NULL,
    phone character varying(20),
    address text,
    photo_url character varying(500),
    face_id character varying(255),
    status character varying(20) NOT NULL,
    archive_year integer DEFAULT 2025 NOT NULL,
    group_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    value text,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    external_id character varying(255),
    amount numeric(15,2) NOT NULL,
    source character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    paid_at timestamp with time zone,
    comment text,
    payment_year integer,
    payment_months json,
    student_id integer,
    contract_id integer,
    created_by_user_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: user_role_association; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_role_association (
    user_id integer NOT NULL,
    role_id integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    phone character varying(20) NOT NULL,
    email character varying(255),
    full_name character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    is_super_admin boolean NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: waiting_list; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.waiting_list (
    id integer NOT NULL,
    student_first_name character varying(100) NOT NULL,
    student_last_name character varying(100) NOT NULL,
    birth_year integer NOT NULL,
    father_name character varying(200),
    father_phone character varying(20),
    mother_name character varying(200),
    mother_phone character varying(20),
    group_id integer NOT NULL,
    priority integer NOT NULL,
    notes text,
    added_by_user_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: waiting_list_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.waiting_list_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: waiting_list_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.waiting_list_id_seq OWNED BY public.waiting_list.id;


--
-- Name: attendances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances ALTER COLUMN id SET DEFAULT nextval('public.attendances_id_seq'::regclass);


--
-- Name: contracts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts ALTER COLUMN id SET DEFAULT nextval('public.contracts_id_seq'::regclass);


--
-- Name: gate_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gate_logs ALTER COLUMN id SET DEFAULT nextval('public.gate_logs_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: parents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parents ALTER COLUMN id SET DEFAULT nextval('public.parents_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: waiting_list id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waiting_list ALTER COLUMN id SET DEFAULT nextval('public.waiting_list_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
7a41de31b9a0
\.


--
-- Data for Name: attendances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendances (id, status, comment, session_id, student_id, marked_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contracts (id, contract_number, start_date, end_date, monthly_fee, status, archive_year, birth_year, sequence_number, passport_copy_url, form_086_url, heart_checkup_url, birth_certificate_url, contract_images_urls, final_pdf_url, custom_fields, terminated_at, terminated_by_user_id, termination_reason, student_id, group_id, created_at, updated_at) FROM stdin;
1	N1B12020	2025-01-06	2025-12-06	600000.00	ACTIVE	2025	2020	1	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/6d78a080-d2a8-4e2b-8d28-bab96cb6cd21.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/752db67f-2533-4e03-81ca-50a4c0bdf657.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/407ea451-0ea3-4844-a53c-6a9142a16e47.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/7070ffc2-8864-4ec1-9a37-4128c9c9d1e9.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/f11c1d71-7615-41aa-85b0-2948727956fc.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/f685b927-b7e8-4ae0-a9bd-4cfd0cb32d71.png"]	https://cognilabs.s3.eu-north-1.amazonaws.com/contract-pdfs/N1B12020_a9c67e22-a155-464a-b9aa-6134b772bd7b.pdf	{"contract_number": "N1B12020", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2020", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Тадбиркор", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2020, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2025-01-06", "tugash": "2025-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	\N	\N	\N	2	1	2025-12-18 23:11:48.331481+05	2025-12-18 23:11:48.342193+05
2	N1C12020	2025-01-06	2025-12-06	600000.00	ACTIVE	2025	2020	1	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/cc0d7939-e4b6-438b-ac5f-2540722038f5.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/85c58d1c-3ede-46e2-94ed-38d173ab1137.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/9a8f9497-b4ef-4de4-9cbe-548a3980df87.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/0944f966-c2d3-4d58-ba17-986226770aaf.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/00731d2b-5471-4044-8e1b-104dc881a67c.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/aefc8fb3-d7d5-4f6d-a32a-e7546d9267fa.png"]	https://cognilabs.s3.eu-north-1.amazonaws.com/contract-pdfs/N1C12020_926d14f0-6868-48c0-be50-952680e4bd9f.pdf	{"contract_number": "N1C12020", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2020", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Таджиков", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2020, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2025-01-06", "tugash": "2025-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	\N	\N	\N	3	6	2025-12-20 01:46:44.110298+05	2025-12-20 01:46:44.12159+05
3	N1C22020	2025-01-06	2025-12-06	600000.00	TERMINATED	2025	2020	2	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/fcf2a989-6823-4eb8-aadd-406db3c61f5a.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/7773d4d4-3834-438e-8bfd-e343b7c64b80.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/3bf2ca7e-c7b2-489f-844a-c55dc7be9b20.png	https://cognilabs.s3.eu-north-1.amazonaws.com/student-documents/40c4229b-b7f4-41fe-b275-1fc27d4b352f.png	["https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/afd5bba9-5360-44d5-8c23-ef3732d8ffc9.png", "https://cognilabs.s3.eu-north-1.amazonaws.com/contracts/d8d70821-0e30-4fd2-ad08-7599b62e212a.png"]	https://cognilabs.s3.eu-north-1.amazonaws.com/contract-pdfs/N1C22020_91f9477b-9ad4-4970-b226-838f6f265a99.pdf	{"contract_number": "N1C22020", "student": {"student_image": "student_photo.png", "student_fio": "Юсупов Абдулборий Баҳодирович", "birth_year": "2020", "student_address": "Тошкент ш. Чилонзор т. Лутфий кўчаси 61-уй", "dad_occupation": "Таджиков", "mom_occupation": "Уй бекаси", "dad_phone_number": "(33) 135-80-09", "mom_phone_number": "(78) 162-16-14", "mom_fullname": "Бахриддинова Гулова Баҳромовна"}, "sana": {"kun": "06", "oy": "Декабр", "yil": "2025"}, "buyurtmachi": {"fio": "Юсупов Абдулборий Баҳодирович", "pasport_seriya": "AA 1234567", "pasport_kim_bergan": "Тошкент ш. Чилонзор т. ИИББ бўлими", "pasport_qachon_bergan": "15.03.2018", "manzil": "Тошкент ш., Чилонзор тумани, Лутфий кўчаси 61-уй", "telefon": "+998 (33) 135-80-09"}, "tarbiyalanuvchi": {"fio": "Юсупов Абдулборий Баҳодирович", "tugilganlik_guvohnoma": "I-AA 9876543", "tugilganlik_yil": 2020, "guvohnoma_kim_bergan": "Тошкент ш. ФҲБ Чилонзор т. бўлими", "guvohnoma_qachon_bergan": "12.04.2012"}, "shartnoma_muddati": {"boshlanish": "2025-01-06", "tugash": "2025-12-06", "yil": "2025"}, "tolov": {"oylik_narx": "600 000", "oylik_narx_sozlar": "олти юз минг"}}	2025-12-20 02:18:35.693+05	1	string	5	6	2025-12-20 01:48:34.50653+05	2025-12-20 02:19:01.026425+05
\.


--
-- Data for Name: gate_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gate_logs (id, allowed, reason, gate_timestamp, student_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.groups (id, name, identifier, description, schedule_days, schedule_time, capacity, status, birth_year, archive_year, coach_id, created_at, updated_at) FROM stdin;
1	U6	1B	6 yoshdagi bolalar uchun	DU|SE|CHOR	13:00-18:00	25	ACTIVE	2020	2025	2	2025-12-18 22:40:36.211027+05	2025-12-18 22:40:36.211027+05
2	U6	2B	6 yoshdagi bolalar uchun	DU|SE|CHOR	12:00-18:00	25	ACTIVE	2020	2025	2	2025-12-18 22:54:52.140075+05	2025-12-18 22:54:52.140075+05
5	U6	3B	6 yoshdagi bolalar uchun	DU|SE|CHOR	14:00-18:00	25	DELETED	2020	2025	3	2025-12-20 01:38:46.549656+05	2025-12-20 01:41:00.22022+05
6	U6	1C	6 yoshdagi bolalar uchun	DU|SE|CHOR	14:00-18:00	2	ACTIVE	2020	2025	3	2025-12-20 01:44:17.973904+05	2025-12-20 01:44:17.973904+05
\.


--
-- Data for Name: parents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parents (id, first_name, last_name, phone, email, relationship_type, student_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, code, description, created_at, updated_at) FROM stdin;
1	finance:transactions:view	View financial transactions	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
2	finance:unassigned:view	View unassigned transactions	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
3	finance:unassigned:assign	Assign unassigned transactions	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
4	finance:transactions:manual	Create manual transactions	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
5	finance:transactions:cancel	Cancel transactions	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
6	students:view	View students	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
7	students:edit	Edit students	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
8	students:manage	Full student management including import	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
9	groups:view	View groups	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
10	groups:edit	Edit groups	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
11	contracts:view	View contracts	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
12	contracts:edit	Edit contracts	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
13	attendance:coach:mark	Mark attendance as coach	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
14	attendance:view	View attendance records	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
15	reports:finance:view	View financial reports	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
16	reports:attendance:view	View attendance reports	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
17	reports:dashboard:view	View dashboard	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
18	settings:system:edit	Edit system settings	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
19	settings:system:view	View system settings	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
20	roles:manage	Manage roles and permissions	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
21	users:manage	Manage users	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
22	gate:logs:view	View gate logs	2025-12-18 22:35:59.990157+05	2025-12-18 22:35:59.990157+05
\.


--
-- Data for Name: role_permission_association; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permission_association (role_id, permission_id) FROM stdin;
2	6
2	14
2	9
2	15
2	2
2	16
2	1
2	22
2	17
2	11
2	19
3	6
3	15
3	2
3	4
3	5
3	1
3	17
3	3
3	11
4	13
4	6
4	14
4	9
5	8
5	6
5	14
5	9
5	7
5	12
5	22
5	10
5	17
5	11
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description, created_at, updated_at) FROM stdin;
1	Super Admin	Full system access	2025-12-18 22:36:00.024882+05	2025-12-18 22:36:00.024882+05
2	Director	Director with access to all reports and management	2025-12-18 22:36:00.024882+05	2025-12-18 22:36:00.024882+05
3	Accountant	Financial management and transactions	2025-12-18 22:36:00.024882+05	2025-12-18 22:36:00.024882+05
4	Coach	Coach with attendance marking capabilities	2025-12-18 22:36:00.024882+05	2025-12-18 22:36:00.024882+05
5	Admin	Administrative staff with student and group management	2025-12-18 22:36:00.024882+05	2025-12-18 22:36:00.024882+05
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, session_date, topic, start_time, end_time, group_id, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.students (id, first_name, last_name, date_of_birth, phone, address, photo_url, face_id, status, archive_year, group_id, created_at, updated_at) FROM stdin;
3	Kevin	Brune	2020-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	2025	6	2025-12-20 01:46:41.655441+05	2025-12-20 01:46:41.655441+05
5	Kevin	Brune	2020-12-06	998901234567	Toshkent shahar	\N	\N	ACTIVE	2025	6	2025-12-20 01:48:32.047838+05	2025-12-20 01:48:32.047838+05
2	Alvaro	Marata	2020-12-06	998901234567	Toshkent shahar	\N	\N	DELETED	2025	1	2025-12-18 23:11:45.867384+05	2025-12-20 02:05:20.071182+05
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (id, key, value, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, external_id, amount, source, status, paid_at, comment, payment_year, payment_months, student_id, contract_id, created_by_user_id, created_at, updated_at) FROM stdin;
1	\N	600000.00	PAYME	SUCCESS	2025-12-20 02:19:56.234+05	string	2025	[1]	5	3	1	2025-12-20 02:20:19.870442+05	2025-12-20 02:20:19.870442+05
2	123456789	600000.00	CLICK	SUCCESS	2025-12-19 21:37:15.85197+05	Click confirmed: attempt 987654321, month 4/2025	2025	[4]	5	3	\N	2025-12-20 02:37:13.796003+05	2025-12-20 02:37:15.850232+05
\.


--
-- Data for Name: user_role_association; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_role_association (user_id, role_id) FROM stdin;
2	4
3	4
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, phone, email, full_name, hashed_password, is_super_admin, status, created_at, updated_at) FROM stdin;
1	+998901234567	string	Super Admin	$2b$12$GS41lpb7MLYSVa88NZucWemQxCeFv.kqEZxF3PbsEOjBT/UGpgXYq	t	ACTIVE	2025-12-18 22:36:00.043542+05	2025-12-18 22:36:00.043542+05
2	+998999220204	user@example.com	string	$2b$12$Apig1aaIv19WVaBNUceFK.UgqHYA/V9e.i09/7T2lWXogN7bGuWXG	f	ACTIVE	2025-12-18 22:37:42.7298+05	2025-12-18 22:37:42.7298+05
3	+998999220206	user@gmail.com	string	$2b$12$2aRb7eiAOztASbtYDpCOPupVRIrV8yn4IL7lIqEapAURfGJs37IFW	f	ACTIVE	2025-12-20 01:08:29.659246+05	2025-12-20 01:08:29.659246+05
\.


--
-- Data for Name: waiting_list; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.waiting_list (id, student_first_name, student_last_name, birth_year, father_name, father_phone, mother_name, mother_phone, group_id, priority, notes, added_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Name: attendances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendances_id_seq', 1, false);


--
-- Name: contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contracts_id_seq', 3, true);


--
-- Name: gate_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gate_logs_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.groups_id_seq', 6, true);


--
-- Name: parents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parents_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 22, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 5, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sessions_id_seq', 1, false);


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.students_id_seq', 5, true);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, false);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transactions_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: waiting_list_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.waiting_list_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: attendances attendances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_pkey PRIMARY KEY (id);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- Name: gate_logs gate_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gate_logs
    ADD CONSTRAINT gate_logs_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: parents parents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parents
    ADD CONSTRAINT parents_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permission_association role_permission_association_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission_association
    ADD CONSTRAINT role_permission_association_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: user_role_association user_role_association_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role_association
    ADD CONSTRAINT user_role_association_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: waiting_list waiting_list_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waiting_list
    ADD CONSTRAINT waiting_list_pkey PRIMARY KEY (id);


--
-- Name: ix_attendances_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_attendances_id ON public.attendances USING btree (id);


--
-- Name: ix_contracts_archive_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contracts_archive_year ON public.contracts USING btree (archive_year);


--
-- Name: ix_contracts_birth_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contracts_birth_year ON public.contracts USING btree (birth_year);


--
-- Name: ix_contracts_contract_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_contracts_contract_number ON public.contracts USING btree (contract_number);


--
-- Name: ix_contracts_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contracts_id ON public.contracts USING btree (id);


--
-- Name: ix_gate_logs_gate_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gate_logs_gate_timestamp ON public.gate_logs USING btree (gate_timestamp);


--
-- Name: ix_gate_logs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gate_logs_id ON public.gate_logs USING btree (id);


--
-- Name: ix_groups_archive_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_groups_archive_year ON public.groups USING btree (archive_year);


--
-- Name: ix_groups_birth_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_groups_birth_year ON public.groups USING btree (birth_year);


--
-- Name: ix_groups_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_groups_id ON public.groups USING btree (id);


--
-- Name: ix_groups_identifier; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_groups_identifier ON public.groups USING btree (identifier);


--
-- Name: ix_groups_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_groups_status ON public.groups USING btree (status);


--
-- Name: ix_parents_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_parents_id ON public.parents USING btree (id);


--
-- Name: ix_parents_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_parents_phone ON public.parents USING btree (phone);


--
-- Name: ix_permissions_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_permissions_code ON public.permissions USING btree (code);


--
-- Name: ix_permissions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_permissions_id ON public.permissions USING btree (id);


--
-- Name: ix_roles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_roles_id ON public.roles USING btree (id);


--
-- Name: ix_sessions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sessions_id ON public.sessions USING btree (id);


--
-- Name: ix_sessions_session_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sessions_session_date ON public.sessions USING btree (session_date);


--
-- Name: ix_students_archive_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_students_archive_year ON public.students USING btree (archive_year);


--
-- Name: ix_students_face_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_students_face_id ON public.students USING btree (face_id);


--
-- Name: ix_students_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_students_id ON public.students USING btree (id);


--
-- Name: ix_system_settings_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_system_settings_id ON public.system_settings USING btree (id);


--
-- Name: ix_system_settings_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_system_settings_key ON public.system_settings USING btree (key);


--
-- Name: ix_transactions_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_transactions_external_id ON public.transactions USING btree (external_id);


--
-- Name: ix_transactions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_transactions_id ON public.transactions USING btree (id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_phone ON public.users USING btree (phone);


--
-- Name: ix_waiting_list_birth_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_waiting_list_birth_year ON public.waiting_list USING btree (birth_year);


--
-- Name: ix_waiting_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_waiting_list_id ON public.waiting_list USING btree (id);


--
-- Name: attendances attendances_marked_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_marked_by_user_id_fkey FOREIGN KEY (marked_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: attendances attendances_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: attendances attendances_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: contracts contracts_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE SET NULL;


--
-- Name: contracts contracts_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: contracts contracts_terminated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_terminated_by_user_id_fkey FOREIGN KEY (terminated_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: gate_logs gate_logs_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gate_logs
    ADD CONSTRAINT gate_logs_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE SET NULL;


--
-- Name: groups groups_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: parents parents_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parents
    ADD CONSTRAINT parents_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: role_permission_association role_permission_association_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission_association
    ADD CONSTRAINT role_permission_association_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permission_association role_permission_association_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission_association
    ADD CONSTRAINT role_permission_association_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sessions sessions_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: students students_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE SET NULL;


--
-- Name: user_role_association user_role_association_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role_association
    ADD CONSTRAINT user_role_association_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_role_association user_role_association_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role_association
    ADD CONSTRAINT user_role_association_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: waiting_list waiting_list_added_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waiting_list
    ADD CONSTRAINT waiting_list_added_by_user_id_fkey FOREIGN KEY (added_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: waiting_list waiting_list_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waiting_list
    ADD CONSTRAINT waiting_list_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict O1rg5OcdLYsd5e6dobuwB0vRfJOvvhzz0PhBXxdvpVDlHImVFgwp7fepuaizFC2

